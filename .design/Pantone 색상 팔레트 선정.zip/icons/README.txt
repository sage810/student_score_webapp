수행평가 아이콘 (Tile 스타일) — 24px 그리드, stroke 1.75, square cap
색은 currentColor라 CSS color로 바뀝니다.

사용 1) 개별 파일: <img src="icons/download.svg"> 또는 인라인 붙여넣기
사용 2) 스프라이트: _sprite.svg 내용을 <body> 맨 위에 붙여넣고
   <span class="icon-tile"><svg class="icon"><use href="#i-download"/></svg></span>

타일 스타일은 design-tokens.css의 --icon-* 토큰과 .icon-tile 레시피를 쓰세요.
